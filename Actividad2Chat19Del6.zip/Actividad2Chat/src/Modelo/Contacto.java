package Modelo;

public class Contacto {

	private String nombre;
	
	public Contacto(String nombre) {
		this.nombre = nombre;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	
}
